const Discord = require("discord.js");
const client = new Discord.Client({ ws: { properties: { $browser: "Discord iOS" }} }); //bot as a mobile
const fs = require('fs');
const keepAlive = require("./server")

const gamedig = require("gamedig");

const config = require("./config.json");

/* const usersMap = new Map();
const LIMIT = 7;
const DIFF = 5000;

  client.on('message', async(message) => {
    if(message.author.bot) return;
    
    if(usersMap.has(message.author.id)) {
        const userData = usersMap.get(message.author.id);
        const { lastMessage, timer } = userData;
        const difference = message.createdTimestamp - lastMessage.createdTimestamp;
        let msgCount = userData.msgCount;
        console.log(difference);

        if(difference > DIFF) {
            clearTimeout(timer);
            console.log('Cleared Timeout');
            userData.msgCount = 1;
            userData.lastMessage = message;
            userData.timer = setTimeout(() => {
                usersMap.delete(message.author.id);
                console.log('Removed from map.')
            }, TIME);
            usersMap.set(message.author.id, userData)
        }
        else {
            ++msgCount;
            if(parseInt(msgCount) === LIMIT) {

               message.reply("Warning: Spamming in this channel is forbidden.");
              message.channel.bulkDelete(LIMIT);
               
            } else {
                userData.msgCount = msgCount;
                usersMap.set(message.author.id, userData);
            }
        }
    }
    else {
        let fn = setTimeout(() => {
            usersMap.delete(message.author.id);
            console.log('Removed from map.')
        }, TIME);
        usersMap.set(message.author.id, {
            msgCount: 1,
            lastMessage : message,
            timer : fn
        });
    }
}) */

client.on("ready", () => {
    console.log(`login as ${client.user.tag} StatusBot`);

    client.user.setActivity(`nothing bylat`, {
        type: "WATCHING"
        //url: "https://www.twitch.tv/monstercat"
      });

    setInterval(UpdateInfo, config.UpdateMessageInterval);
});


fs.readdir("./events/", (err, files) => {
  if (err) return console.error(err);
  files.forEach(file => {
      const event = require(`./events/${file}`);
      let eventName = file.split(".")[0];
      console.log(`Loading event ${eventName}`);
      client.on(eventName, event.bind(null, client));
    });
});

client.commands = new Discord.Collection();

fs.readdir("./commands/", (err, files) => {
    if (err) return console.error(err);
    files.forEach(file => {
        if (!file.endsWith(".js")) return;
        let props = require(`./commands/${file}`);
        let commandName = file.split(".")[0];
        console.log(`Loaded ${commandName}`);
        client.commands.set(commandName, props);
    });
});


keepAlive()
client.login(config.token);

function UpdateInfo() {
    let channel = client.channels.cache.get(config.ChannelId);
    channel.messages.fetch({ limit: 1 }).then(messages => {
        let lastMessage = messages.first();
        if(lastMessage == null || lastMessage.author.id != client.user.id){
            SendMessage(channel);
        }
        else{
            UpdateEmbed(lastMessage);
        }
    });
}

async function SendMessage(channel){
    let players = 0;
    let maxplayers = 0;
    let embed = new Discord.MessageEmbed()
    var server;
    try{
        for(var i = 0; i < config.Servers.length; i++){
            var x = config.Servers[i];
            server = await gamedig.query({
                type: config.GameName,
                host: x.ServerIp,
                port: x.ServerPort
            }).catch((error) => {
 /*               message.channel.send("@891652763300286464").then(msg => {
                message.client.channel.get("891509349942460446").send(staffRole).then(function(message) {
                 msg.delete(5)
                }).catch(function() {
                 //do something
                  })
                }); */
                console.log("Timeout or error on " + x.ServerIp + ":" + x.ServerPort)
            })
            if(server != null){
      //          message.channel.send("<@891652763300286464>")
                players += server.players.length;
                maxplayers += server.maxplayers;
                var canAddUnsafe = false;
                var localPlayers = server.players.length;
                if(x.UnsafeCount && server.bots[0].name != null) {
                    localPlayers += server.bots.length;
                    players += server.bots.length;
                    canAddUnsafe = true;
                }
                embed.addFields(
                    {
                        name: config.EmbedInfo.ServerField1.replace("<servername>", server.name), value: config.EmbedInfo.ServerField2.replace("<ip>", server.connect).replace("<map>", server.map).replace("<players>", localPlayers).replace("<maxplayers>", server.maxplayers)
                    }
                )
                if(x.ShowPlayers){
                    for(var o = 0; o < server.players.length; o++){
                        var player = server.players[o];
                        embed.addFields({
                            name: ":bust_in_silhouette: " + player.name, value: "Playing" , 
                            /*":hourglass_flowing_sand: " + GetTime(player.raw.time), */inline: true
                        })
                    }

                    if(canAddUnsafe){
                        for(var o = 0; o < server.players.length; o++){
                            var bot = server.bots[o];
                            embed.addFields({
                                name: ":bust_in_silhouette: " + bot.name, value: ":hourglass_flowing_sand: " + GetTime(bot.raw.time), inline: true
                            })
                        }
                    }
                } 
            }
        }
    }
    finally{
        embed.setColor(config.EmbedInfo.Color);
        embed.setTitle(config.EmbedInfo.Title)
        embed.setDescription(config.EmbedInfo.Description.replace("<players>", players).replace("<maxplayers>", maxplayers))
        channel.send(embed);
    }
}


let staffRole = "<@891652763300286464>"

async function UpdateEmbed (message){
    let players = 0;
    let maxplayers = 0;
    let embed = new Discord.MessageEmbed()
    var server;
    try{
        for(var i = 0; i < config.Servers.length; i++){
            var x = config.Servers[i];
            server = await gamedig.query({
                type: config.GameName,
                host: x.ServerIp,
                port: x.ServerPort
            }).catch((error) => {
/*                message.channel.send("<@891652763300286464>").then(msg => {
                message.client.channel.get("891509349942460446").send(staffRole).then(function(message) {
                 msg.delete(5)
                }).catch(function() {
                 //do something
                  })
                }); */
                console.log("Timeout or error on " + x.ServerIp + ":" + x.ServerPort)
            })
            if(server != null){
             //   message.channel.send("<@891652763300286464>")
                players += server.players.length;
                maxplayers += server.maxplayers;
                var canAddUnsafe = false;
                var localPlayers = server.players.length;
                if(x.UnsafeCount && server.bots[0].name != null) {
                    localPlayers += server.bots.length;
                    players += server.bots.length;
                    canAddUnsafe = true;
                }
                embed.addFields(
                    {
                        name: config.EmbedInfo.ServerField1.replace("<servername>", server.name), value: config.EmbedInfo.ServerField2.replace("<ip>", server.connect).replace("<map>", server.map).replace("<players>", localPlayers).replace("<maxplayers>", server.maxplayers)
                    }
                )
                if(x.ShowPlayers){
                    for(var o = 0; o < server.players.length; o++){
                        var player = server.players[o];
                        embed.addFields({
                            name: ":bust_in_silhouette: " + player.name, value: "Playing" ,
                            /* value: ":hourglass_flowing_sand: " + GetTime(player.raw.time), */ inline: true
                        })
                    }

                    if(canAddUnsafe){
                        for(var o = 0; o < server.players.length; o++){
                            var bot = server.bots[o];
                            embed.addFields({
                                name: ":bust_in_silhouette: " + bot.name, value: ":hourglass_flowing_sand: " + GetTime(bot.raw.time), inline: true
                            })
                        }
                    }
                }
            }
        }
    }
    finally{
        embed.setColor(config.EmbedInfo.Color);
        embed.setTitle(config.EmbedInfo.Title);
        embed.setDescription(config.EmbedInfo.Description.replace("<players>", players).replace("<maxplayers>", maxplayers));
        message.edit(embed);
    }
}

client.on('message', async message => {
 let args = message.content.slice(config.prefix.length).trim() .split(/ +/)
  let command = args.shift().toLowerCase()


  //do somthing

  if (!message.content.startsWith(config.prefix) || message.author.bot) return


})


function GetTime(ms) {
    ms *= 1000;
    const sec = Math.floor((ms / 1000) % 60).toString()
    const min = Math.floor((ms / (1000 * 60)) % 60).toString()
    const hrs = Math.floor((ms / (1000 * 60 * 60)) % 60).toString()
    const days = Math.floor((ms / (1000 * 60 * 60 * 24)) % 60).toString()
    return `${days.padStart(1, `0`)}d ${hrs.padStart(2, `0`)}h ${min.padStart(2, `0`)}m ${sec.padStart(3, `0`)}s` 
}
