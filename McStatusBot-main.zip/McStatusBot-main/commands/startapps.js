const Jsonfile = require('../config.json');
exports.run = async (client, message, args) => {

/* let user = message.author;
       let timeout = "600000";
     //   var weekly =  db.fetch(`messageem_${message.guild.id}_${user.id}`);
   if (weekly !== null && timeout - (Date.now() - weekly) > 0) {
    let time = ms(timeout - (Date.now() - weekly));
    message.channel.send("You cant You can only create 1 ticket in 1 hour to Avoid Spam Tickets")
   } */


if (message.author.id !== Jsonfile.owner) return message.channel.send("Sorry but you cant use this command D:").then((msg) => {
    setTimeout(() => msg.delete(), 7000);
})
    const signup = await message.channel.send({embed: {
        color: Jsonfile.signup_color,
        fields: [{
           name: Jsonfile.signup_title,      
      //    name: `{guild.name}`,           
           value: "**Clubkhmer Ticket** \n If you have any problem you can open for help Thanks!\n - __Please don't spam Tickets__.  \n\n To create a ticket react with  📩",
        //   value1: "To create a ticket react with  📩"
          }
        ],
        timestamp: new Date(),
        footer: {
          icon_url: client.user.avatarURL()
        }
      }
    });
    await signup.react("📩")
    const collector = signup.createReactionCollector(
        (reaction, user) => message.guild.members.cache.find((member) => member.id === user.id),
        { dispose: true }
        );
    collector.on("collect", (reaction, user) => {
        switch (reaction.emoji.name) {
            case "📩":
                contining(user)
            break;
      
        //this.message.react('📩');    
      }
      //reaction.users.remove()
      reaction.users.remove(user)
       
    })
    
    async function contining(user){
        const channel = await message.guild.channels.create(`ticket: ${user.username + "-" + user.discriminator}`);

        channel.updateOverwrite(message.guild.id, {
        "SEND_MESSAGE": false,
        "VIEW_CHANNEL": false,
        });
        channel.updateOverwrite(user.id, {
        "SEND_MESSAGE": true,
        "VIEW_CHANNEL": true,
        });

        const reactionMessage = await channel.send({embed: {
            color: Jsonfile.answer_color,
            fields: [{
                name: Jsonfile.answer_title,
                value: Jsonfile.answer_description
              }
            ],
            timestamp: new Date(),
            footer: {
              icon_url: client.user.avatarURL()
            }
          }
        })
        await reactionMessage.react("🔒");
        await reactionMessage.react("⛔");

        const collector = reactionMessage.createReactionCollector(
        (reaction, user) => message.guild.members.cache.find((member) => member.id === user.id).hasPermission("ADMINISTRATOR"),
        { dispose: true }
        );
        

        collector.on("collect", (reaction, user) => {
        switch (reaction.emoji.name) {   
            //case "📩":
            //message.react("");
            case "🔒":
            channel.updateOverwrite(user.id, { "SEND_MESSAGES": false });
            channel.send("Channel has been locked!");
            break;
            case "⛔":
            if (message.guild.channels.cache.find(c => c.name.toLowerCase() === channel.name)) { //checks if there in an item in the channels collection that corresponds with the supplied parameters, returns a boolean
                setTimeout(() => channel.delete(), 5000);
                channel.send("Deleting this channel in 5 seconds!");
                return;
            }
            break;
        } 
        });
    }
}