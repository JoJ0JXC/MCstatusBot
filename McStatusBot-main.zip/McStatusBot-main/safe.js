const discord = require("discord.js");
const prefix = require("./config.json");

module.exports = {
    name: "",



    execute: async(client, args, message) => {
        
     const embed = MessageEmbed()
     .setAuthor("");
     
     .addField("");



    }

} 