# McStatusBot
Please leave a credit when use our source code
# [Discord](https://discord.io/theanchill) / By thunthean#0063 

# Config file 
````
{
    "token": "TOKEN", 
    "UpdateMessageInterval": 4000,
    "ChannelId": "893016411843215361",
    "GameName": "minecraft",
    "EmbedInfo": {
        "Title": "BotServers Status!\n\n IP: `[chestersmp.mcpe.lol]`\n `Ports: 19377` \n ||Port: 1980|| \n\n Playing : `Minecraft`",
        "Color": "#008000",
        "Description": "Check out our Status servers feel free to join in all !\n\n**Total Players:** <players>/<maxplayers>",
        "ServerField1": "__<servername>__",
        "ServerField2": "**Adress: [<ip>](https://discord.gg/)  Map: [<map>](https://discord.gg/)  Players: [<players>/<maxplayers>](https://discord.gg/)**"
    },
     
     "owner": "597271012979113984",
     "prefix": "?",
    

    "Servers": [   
        {
            "ServerIp": "chestersmp.mcpe.lol",
            "ServerPort": "19377",
            "ShowPlayers": true,
            "UnsafeCount": false
        }
        
    ]
}
````
